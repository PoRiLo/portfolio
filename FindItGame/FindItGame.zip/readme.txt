Small personal project to practice my ESRI ArcGIS API for JavaScript skills. Created with API version 4.17.

To deploy it, simply extract the files to a folder and open index.html in a browser.

The game consist in clicking on a series of countries before the time ends.

