define({
  "_widgetLabel": "Celá obrazovka"
});