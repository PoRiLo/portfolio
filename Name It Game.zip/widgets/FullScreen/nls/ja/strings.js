define({
  "_widgetLabel": "全画面表示"
});