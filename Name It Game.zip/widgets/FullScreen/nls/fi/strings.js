define({
  "_widgetLabel": "Koko näyttö"
});