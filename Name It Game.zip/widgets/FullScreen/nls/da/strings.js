define({
  "_widgetLabel": "Fuld skærm"
});