define({
  "_widgetLabel": "Pantalla completa"
});