define({
  "_widgetLabel": "Layar Penuh"
});