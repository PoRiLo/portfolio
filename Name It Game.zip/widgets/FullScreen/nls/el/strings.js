define({
  "_widgetLabel": "Πλήρης οθόνη"
});