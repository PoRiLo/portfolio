define({
  "_widgetLabel": "전체 화면"
});