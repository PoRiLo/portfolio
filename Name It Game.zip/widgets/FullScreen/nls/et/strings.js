define({
  "_widgetLabel": "Täisekraan"
});