define({
  "_widgetLabel": "ملء الشاشة"
});