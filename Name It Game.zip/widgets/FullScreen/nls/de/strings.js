define({
  "_widgetLabel": "Vollbild"
});