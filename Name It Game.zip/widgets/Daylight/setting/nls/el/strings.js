define({
  "defaultTimeZone": "Καθορισμός της προεπιλεγμένης ζώνης ώρας:"
});