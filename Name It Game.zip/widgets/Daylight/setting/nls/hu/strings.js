define({
  "defaultTimeZone": "Alapértelmezett időzóna beállítása:"
});