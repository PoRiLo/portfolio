define({
  "defaultTimeZone": "Setați fusul orar implicit:"
});