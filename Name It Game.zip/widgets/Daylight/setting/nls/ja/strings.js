define({
  "defaultTimeZone": "デフォルト タイム ゾーンの設定:"
});