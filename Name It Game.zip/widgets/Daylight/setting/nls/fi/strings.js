define({
  "defaultTimeZone": "Määritä oletusaikavyöhyke:"
});