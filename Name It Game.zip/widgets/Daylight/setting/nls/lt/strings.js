define({
  "defaultTimeZone": "Nustatyti numatytąją laiko juostą:"
});