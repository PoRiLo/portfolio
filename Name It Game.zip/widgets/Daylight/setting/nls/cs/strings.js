define({
  "defaultTimeZone": "Nastavit výchozí časové pásmo:"
});