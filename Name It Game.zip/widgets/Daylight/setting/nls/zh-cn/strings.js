define({
  "defaultTimeZone": "设置默认时区："
});