define({
  "defaultTimeZone": "Angi standard tidssone:"
});