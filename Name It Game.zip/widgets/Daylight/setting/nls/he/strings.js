define({
  "defaultTimeZone": "הגדר ברירת מחדל לאזור זמן:"
});