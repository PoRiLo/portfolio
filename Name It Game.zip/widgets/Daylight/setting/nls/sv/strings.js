define({
  "defaultTimeZone": "Ange standardtidszon:"
});