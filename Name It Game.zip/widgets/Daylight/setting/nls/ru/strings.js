define({
  "defaultTimeZone": "Задать часовой пояс по умолчанию:"
});