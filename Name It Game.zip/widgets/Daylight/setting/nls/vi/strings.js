define({
  "defaultTimeZone": "Thiết lập múi giờ mặc định:"
});