define({
  "defaultTimeZone": "Podesite podrazumevanu vremensku zonu:"
});