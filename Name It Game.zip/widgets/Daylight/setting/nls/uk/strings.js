define({
  "defaultTimeZone": "Задати часовий пояс за замовчуванням:"
});