define({
  "defaultTimeZone": "Iestatīt noklusējuma laika joslu:"
});