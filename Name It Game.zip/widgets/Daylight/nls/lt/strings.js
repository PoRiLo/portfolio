define({
  "_widgetLabel": "Apšvietimas",
  "dragSunSliderText": "Norėdami pakeisti laiką, paslinkite slankiklį.",
  "directShadow": "Tiesioginis šešėlis (metamas saulės šviesos)",
  "diffuseShadow": "Prieblanda (aplinkos okliuzija)",
  "shadowing": "Šešėliavimas"
});