define({
  "_widgetLabel": "Dagsljus",
  "dragSunSliderText": "Dra skjutreglaget för att ändra klockslag.",
  "directShadow": "Direkt skugga (av solljus)",
  "diffuseShadow": "Diffusa skuggor (av omgivning)",
  "shadowing": "Skugga"
});