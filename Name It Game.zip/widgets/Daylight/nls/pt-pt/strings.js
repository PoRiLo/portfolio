define({
  "_widgetLabel": "Luz do Dia",
  "dragSunSliderText": "Arrastar a barra deslizante para alterar a hora do dia.",
  "directShadow": "Sombra direta (proveniente da luz do sol)",
  "diffuseShadow": "Sombras Difusas (oclusão do ambiente)",
  "shadowing": "Sombreamento"
});