define({
  "_widgetLabel": "일광",
  "dragSunSliderText": "시간을 변경하려면 슬라이더를 드래그합니다.",
  "directShadow": "직접 그림자(태양광)",
  "diffuseShadow": "산란 그림자(ambient occlusion)",
  "shadowing": "그림자 처리"
});