define({
  "_widgetLabel": "Dagslys",
  "dragSunSliderText": "Dra glidebryteren for å endre tid på dagen.",
  "directShadow": "Direkte skygge (fra solskinn)",
  "diffuseShadow": "Diffuse skygger (fra omgivelsene)",
  "shadowing": "Skyggelegging"
});