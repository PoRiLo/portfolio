define({
  "_widgetLabel": "Zi",
  "dragSunSliderText": "Trageţi glisorul pentru a schimba ora din zi.",
  "directShadow": "Umbră directă (produsă de lumina soarelui)",
  "diffuseShadow": "Umbre difuze (blocare ambientală)",
  "shadowing": "Umbrire"
});