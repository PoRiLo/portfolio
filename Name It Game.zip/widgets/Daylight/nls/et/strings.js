define({
  "_widgetLabel": "Päevavalgus",
  "dragSunSliderText": "Lohistage liugurit, et muuta kellaaega.",
  "directShadow": "Otsene varjutus (päikesevalgus)",
  "diffuseShadow": "Hajus varjutus (ümbritsev varjamine)",
  "shadowing": "Varjutamine"
});