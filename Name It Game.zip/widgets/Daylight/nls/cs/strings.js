define({
  "_widgetLabel": "Denní světlo",
  "dragSunSliderText": "Táhnutím za posuvník můžete měnit čas.",
  "directShadow": "Přímý stín (vrhán slunečním světlem)",
  "diffuseShadow": "Rozptýlené stíny (vrhány okolním světlem)",
  "shadowing": "Stínování"
});