define({
  "_widgetLabel": "Lumière du jour",
  "dragSunSliderText": "Faites glisser le curseur pour changer l'heure de la journée.",
  "directShadow": "Ombre directe (projetée par la lumière du soleil)",
  "diffuseShadow": "Ombres diffuses (pénombre ambiante)",
  "shadowing": "Ombrage"
});