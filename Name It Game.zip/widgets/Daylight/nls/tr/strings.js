define({
  "_widgetLabel": "Gün Işığı",
  "dragSunSliderText": "Günün saatini değiştirmek için kaydırıcıyı sürükleyin.",
  "directShadow": "Doğrudan gölge (günışığı vurduğunda)",
  "diffuseShadow": "Dağınık gölgeler (ortama bağlı oklüzyon)",
  "shadowing": "Gölgeleme"
});