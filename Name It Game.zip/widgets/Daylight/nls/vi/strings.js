define({
  "_widgetLabel": "Ánh sáng ban ngày",
  "dragSunSliderText": "Kéo thanh trượt để thay đổi thời gian trong ngày.",
  "directShadow": "Tạo bóng trực tiếp (truyền theo ánh mặt trời)",
  "diffuseShadow": "Bóng khuếch tán (bịt kín xung quanh)",
  "shadowing": "Tạo bóng"
});