define({
  "_widgetLabel": "Dienasgaisma",
  "dragSunSliderText": "Velciet slāni, lai mainītu diennakts laiku.",
  "directShadow": "Tiešā ēna (no saules)",
  "diffuseShadow": "Izkliedētas ēnas (apkārtējā oklūzija)",
  "shadowing": "Ēnojums"
});