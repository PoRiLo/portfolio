define({
  "_widgetLabel": "日光",
  "dragSunSliderText": "拖动滑块更改时间。",
  "directShadow": "直接阴影(阳光投射)",
  "diffuseShadow": "散射阴影(环境遮挡)",
  "shadowing": "阴影"
});