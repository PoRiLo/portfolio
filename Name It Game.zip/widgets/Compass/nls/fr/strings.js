define({
  "_widgetLabel": "Boussole"
});