define({
  "_widgetLabel": "コンパス"
});