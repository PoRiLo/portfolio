define({
  "_widgetLabel": "Kompassi"
});