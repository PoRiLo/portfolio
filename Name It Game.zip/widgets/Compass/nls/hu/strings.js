define({
  "_widgetLabel": "Iránytű"
});