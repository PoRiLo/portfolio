define({
  "_widgetLabel": "La bàn"
});