define({
  "_widgetLabel": "羅盤儀"
});