define({
  "_widgetLabel": "Brúixola"
});