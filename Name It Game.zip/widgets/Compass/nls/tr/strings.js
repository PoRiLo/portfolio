define({
  "_widgetLabel": "Pusula"
});