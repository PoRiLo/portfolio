﻿define({
  root: ({
    _widgetLabel: "FindIt",
    label1: "Vind het land",
    label2: "Vindt u deze landen: ",
	countryCliked: "U heeft geklikt op ",
	footnote: "Om een nieuw lijst te krigen, sluit en open de widget opnieuw"
  })
});