define({
  root: ({
    _widgetLabel: "FindIt",
    label1: "Find the country",
    label2: "Find these countries: ",
	countryCliked: "You clicked on ",
	footnote: "To get a new list, close and open the widget again"
  }),
  'en': true,
  'es': true,
  'nl': true
});