define({
  "_themeLabel": "Tema do Painel",
  "_layout_default": "Layout padrão",
  "_layout_right": "Layout à direita"
});