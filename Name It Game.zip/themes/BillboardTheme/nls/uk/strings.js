define({
  "_themeLabel": "Тема Billboard",
  "_layout_default": "Компонування за замовчуванням",
  "_layout_right": "Компонування справа"
});