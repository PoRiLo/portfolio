define({
  "_themeLabel": "Teema Billboard",
  "_layout_default": "Vaikimisi paigutus",
  "_layout_right": "Parempoolne paigutus"
});