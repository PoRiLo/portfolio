define({
  "_themeLabel": "Izkārtnes tēma",
  "_layout_default": "Noklusējuma izkārtojums",
  "_layout_right": "Izkārtojums pa labi"
});