define({
  "_themeLabel": "Billboard-Design",
  "_layout_default": "Standard-Layout",
  "_layout_right": "Rechtes Layout"
});