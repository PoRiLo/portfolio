define({
  "_themeLabel": "ערכת נושא לוח מודעות",
  "_layout_default": "פריסת ברירת מחדל",
  "_layout_right": "פריסה ימנית"
});